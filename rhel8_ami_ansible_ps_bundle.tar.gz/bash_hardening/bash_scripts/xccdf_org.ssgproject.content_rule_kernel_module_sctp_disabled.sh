echo "install sctp /bin/true" >> /etc/modprobe.d/blacklist.conf
echo "blacklist sctp" >> /etc/modprobe.d/blacklist.conf
