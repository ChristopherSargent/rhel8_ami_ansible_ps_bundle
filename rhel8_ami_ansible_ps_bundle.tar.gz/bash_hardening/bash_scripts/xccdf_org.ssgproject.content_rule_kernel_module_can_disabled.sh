echo "install can /bin/true" >> /etc/modprobe.d/blacklist.conf
echo "blacklist can" >> /etc/modprobe.d/blacklist.conf
