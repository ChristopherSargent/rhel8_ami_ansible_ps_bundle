echo "install tipc /bin/true" >> /etc/modprobe.d/blacklist.conf
echo "blacklist tipc" >> /etc/modprobe.d/blacklist.conf
