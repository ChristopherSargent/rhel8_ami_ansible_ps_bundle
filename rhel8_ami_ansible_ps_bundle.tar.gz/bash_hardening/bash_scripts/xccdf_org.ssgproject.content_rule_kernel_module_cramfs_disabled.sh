echo "install cramfs /bin/true" >> /etc/modprobe.d/blacklist.conf
echo "blacklist cramfs" >> /etc/modprobe.d/blacklist.conf
